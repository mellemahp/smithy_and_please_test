Rust build rules
================

This is a *very* incomplete set of build rules for Rust.

Currently they're about as basic as can be, there is basic
test support but nothing for Cargo as yet.
https://github.com/rust-lang/rust-roadmap/issues/12 is generally
related to this topic.
