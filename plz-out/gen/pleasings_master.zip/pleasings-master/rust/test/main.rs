// Very simple main to test our library.
extern crate lib;

fn main() {
    println!("The answer is {}", lib::add_two(40));
}
