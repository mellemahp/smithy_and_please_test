#!/bin/sh
# Just run the binary, if it exits without segfaulting we'll call it a win.
exec $DATA
