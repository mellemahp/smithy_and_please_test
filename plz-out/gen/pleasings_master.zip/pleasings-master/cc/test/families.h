#ifndef _CC_TEST_FAMILIES_H
#define _CC_TEST_FAMILIES_H

#include "cc/test/family.h"

// Returns a predefined cat family.
Family TibblesFamily();


#endif  // _CC_TEST_FAMILIES_H
