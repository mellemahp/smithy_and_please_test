const ReactDOM = require('react-dom');
const React = require('react');
import Game from 'js/example/game';

ReactDOM.render(<Game />, document.getElementById("root"));
