// Load the core build.
const _ = require('lodash/core');

exports.getLodashVersion = function(){
    return _.VERSION
}
