let foo = require("@example/foo_lib")

console.log(foo.getLodashVersion())