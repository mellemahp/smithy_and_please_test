package foo

type Foo interface {
	Foo() string
}

